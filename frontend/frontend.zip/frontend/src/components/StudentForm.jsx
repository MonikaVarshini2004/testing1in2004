import { useState, useEffect } from "react";

const StudentForm = ({ onSubmit, editingStudent, cancelEdit }) => {
  const [student, setStudent] = useState({
    name: "",
    department: ""
  });

  useEffect(() => {
    if (editingStudent) {
      setStudent(editingStudent);
    }
  }, [editingStudent]);

  const handleChange = (e) => {
    setStudent({
      ...student,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!student.name || !student.department) {
      alert("All fields are required");
      return;
    }

    onSubmit(student);

    setStudent({ name: "", department: "" });
  };

  return (
    <div className="form-container">
      <h3>{editingStudent ? "Edit Student" : "Add Student"}</h3>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Enter Name"
          value={student.name}
          onChange={handleChange}
        />

        <input
          type="text"
          name="department"
          placeholder="Enter Department"
          value={student.department}
          onChange={handleChange}
        />

        <button type="submit">
          {editingStudent ? "Update" : "Add"}
        </button>

        {editingStudent && (
          <button type="button" onClick={cancelEdit}>
            Cancel
          </button>
        )}
      </form>
    </div>
  );
};

export default StudentForm;
